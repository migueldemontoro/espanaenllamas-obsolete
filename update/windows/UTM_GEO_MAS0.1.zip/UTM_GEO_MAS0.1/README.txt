La estructura del archivo *.in es la siguiente:

Primera l�nea: numero de registros en el archivo a procesar. A continuaci�n (se puede dejar una linea para mejor legibilidad):

primer campo
************
elipsoide de referencia: 1 para Hayford, 2 para WGS 84

segundo campo
**************
huso

tercer campo
**************
n (minuscula o mayuscula) para hemisferio norte; s (minuscula o mayuscula) para hemisferio sur

cuarto campo
**************
coordenada X (metros)

quinto campo
**************
coordenada Y (metros)